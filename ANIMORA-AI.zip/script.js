const $ = (id) => document.getElementById(id);
const pages = ["home","chat","image","video","animate","voice","editor","projects"];
const pageTitles = {home:"Overview",chat:"AI Chat",image:"AI Image",video:"AI Video",animate:"Image to Video",voice:"AI Voice",editor:"Video Editor",projects:"My Projects"};
let projects = [];

function showToast(message){
  const toast=$("toast"); toast.textContent=message; toast.classList.add("show");
  clearTimeout(showToast.timer); showToast.timer=setTimeout(()=>toast.classList.remove("show"),2800);
}
function navigate(page){
  if(!pages.includes(page)) return;
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active-page"));
  $("page-"+page).classList.add("active-page");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  $("pageName").textContent=pageTitles[page];
  $("sidebar").classList.remove("open");
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
$("mobileMenu").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("themeButton").addEventListener("click",()=>{document.body.classList.toggle("alt-accent");showToast("Accent theme changed.");});

function addProject(type, prompt, details){
  projects.unshift({type,prompt,details,created:new Date().toLocaleString()});
  renderProjects();
}
function renderProjects(){
  const box=$("projectsList");
  if(!projects.length){box.innerHTML='<div class="empty-projects"><span>▤</span><b>No projects yet</b><p>Your prepared generation requests will be listed here.</p></div>';return;}
  box.innerHTML=projects.map(p=>`<div class="project-item"><small>${escapeHTML(p.type)} • ${escapeHTML(p.created)}</small><p>${escapeHTML(p.prompt)}</p><b>${escapeHTML(p.details)}</b></div>`).join("");
}
function escapeHTML(value){
  return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function prepareRequest(promptId, outputId, type, details){
  const prompt=$(promptId).value.trim();
  if(!prompt){showToast("Please enter a prompt first.");$(promptId).focus();return;}
  $(outputId).classList.remove("hidden");
  $(outputId).textContent=`Request prepared — ${details}. Prompt: ${prompt}. To generate actual ${type.toLowerCase()}, connect a compatible API through a secure backend.`;
  addProject(type,prompt,details);
  showToast(`${type} request added to My Projects.`);
}
$("imageGenerate").addEventListener("click",()=>prepareRequest("imagePrompt","imageRequest","Image",`${$("imageStyle").value}, ${$("imageRatio").value}`));
$("videoGenerate").addEventListener("click",()=>prepareRequest("videoPrompt","videoRequest","Video",`${$("videoDuration").value}, ${$("videoRatio").value}`));

$("animateUpload").addEventListener("change",e=>{
  const file=e.target.files[0]; if(!file)return;
  if(!file.type.startsWith("image/")){showToast("Please choose an image file.");return;}
  const url=URL.createObjectURL(file);
  $("animatePreview").innerHTML=`<img src="${url}" alt="Selected image preview">`;
  $("animatePreview").classList.remove("hidden");
  showToast("Image loaded for local preview.");
});
$("animatePrepare").addEventListener("click",()=>{
  const file=$("animateUpload").files[0], prompt=$("motionPrompt").value.trim();
  if(!file){showToast("Choose an image first.");return;}
  if(!prompt){showToast("Describe the motion first.");$("motionPrompt").focus();return;}
  $("animateRequest").classList.remove("hidden");
  $("animateRequest").textContent=`Animation request prepared for ${file.name}. Motion: ${prompt}. Connect an image-to-video API to render the animation.`;
  addProject("Image to Video",`${file.name}: ${prompt}`,"Animation request prepared");
  showToast("Animation request added to My Projects.");
});

$("chatForm").addEventListener("submit",e=>{
  e.preventDefault();const input=$("chatInput"),text=input.value.trim();if(!text)return;
  const messages=$("chatMessages");
  const user=document.createElement("div");user.className="message user";
  user.innerHTML=`<div><b>You</b><p>${escapeHTML(text)}</p></div><span class="message-avatar">A</span>`;
  messages.appendChild(user);
  const reply=document.createElement("div");reply.className="message assistant";
  reply.innerHTML='<span class="message-avatar">✧</span><div><b>Animora Assistant • Demo</b><p>This is the chat interface preview. Connect an AI model through a secure backend to receive real AI answers.</p></div>';
  messages.appendChild(reply);input.value="";messages.scrollTop=messages.scrollHeight;
});

let currentObjectURL=null;
$("videoUpload").addEventListener("change",e=>{
  const file=e.target.files[0];if(!file)return;
  if(!file.type.startsWith("video/")){showToast("Please choose a video file.");return;}
  if(currentObjectURL)URL.revokeObjectURL(currentObjectURL);
  currentObjectURL=URL.createObjectURL(file);
  $("editorVideo").src=currentObjectURL;$("editorVideo").classList.remove("hidden");
  showToast("Video loaded. Use the player controls to preview.");
});
$("volumeControl").addEventListener("input",e=>$("editorVideo").volume=Number(e.target.value));
$("playbackRate").addEventListener("change",e=>$("editorVideo").playbackRate=Number(e.target.value));

$("speakButton").addEventListener("click",()=>{
  const text=$("voiceText").value.trim();if(!text){showToast("Enter voiceover text first.");return;}
  if(!("speechSynthesis" in window)){showToast("Speech synthesis is not supported in this browser.");return;}
  speechSynthesis.cancel();
  const utterance=new SpeechSynthesisUtterance(text);
  utterance.lang=$("voiceLanguage").value;utterance.rate=Number($("voiceRate").value);
  speechSynthesis.speak(utterance);
});
$("stopSpeak").addEventListener("click",()=>{if("speechSynthesis" in window)speechSynthesis.cancel();showToast("Voice playback stopped.");});

window.addEventListener("beforeunload",()=>{if(currentObjectURL)URL.revokeObjectURL(currentObjectURL);});
